	You look at the deserted lands
	Empty dams, buildings, civilization
	Waiting to be claimed
	It’s time you accept this Catastrophe
	And become the conqueror
	With your four bare paws
	And humans to do your bidding
