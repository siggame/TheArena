TODO: document rules
