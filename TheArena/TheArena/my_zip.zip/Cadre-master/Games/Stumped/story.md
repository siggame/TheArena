	You sit at the bar, and stare confused as a group of spiders swarm each other in the cobweb in the corner. The barkeep swats them down with his broom and you signal for another ale. The beer slides down the table but is stopped early by your arch nemesis from the ranch down the street. He takes a swig; you stand up and knock over your stool. 
	He walks over to you and stands so close you can smell your beer on his breath. 
	“Well, word ‘round town has it you’re gunnin’ for the sheriff’s office. You know I can’t have that.” 
	“Now why’s that? I heard that you’re gonna spike the town’s water supply,” you spit back.
	“Sound’s like I got a rat to find. Either way, ain’t no way I’m givin’ you that star.” You pull out your revolver and every cowboy in the saloon stands up. 
	“This town isn’t big enough for the 10 of us.”
