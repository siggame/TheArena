# Games/

This folder should house cross-project game data. For example, the main data file to run with Creer. We don't want to clutter up Creer with tons of data files un-related to each other, as Creer should remain a game agnostic code generation tool.

It's also a good idea to put any help, story, or rule documentation in the appriopraite game folder, so it doesn't get lost.
