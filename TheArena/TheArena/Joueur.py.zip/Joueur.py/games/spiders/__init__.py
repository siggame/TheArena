# DO NOT MODIFY THESE IMPORTS
from games.spiders.ai import AI
from games.spiders.game import Game
from games.spiders.brood_mother import BroodMother
from games.spiders.cutter import Cutter
from games.spiders.game_object import GameObject
from games.spiders.nest import Nest
from games.spiders.player import Player
from games.spiders.spider import Spider
from games.spiders.spiderling import Spiderling
from games.spiders.spitter import Spitter
from games.spiders.weaver import Weaver
from games.spiders.web import Web

# <<-- Creer-Merge: init -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
# if you need to initialize this module with custom logic do so here
# <<-- /Creer-Merge: init -->>
