Do not edit any files in the `impl/` directory.

The only file you should ever edit are `ai.hpp` and `ai.cpp`, and if you add files those plus `additional_files.txt` with the paths to those files.
